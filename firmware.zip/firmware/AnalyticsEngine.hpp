#ifndef ANALYTICS_ENGINE_HPP
#define ANALYTICS_ENGINE_HPP

#include <Arduino.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include "BmsEngine.hpp"
#include "FaultStateMachine.hpp"

namespace BMS {

enum class SeverityLevel {
    NOMINAL = 0, // Green
    ADVISORY,    // Yellow
    WARNING,     // Orange
    CRITICAL     // Red
};

struct AnalyticsMetrics {
    float composite_risk_score{0.0f};  // 0.0 (Perfect Health) to 100.0 (Immediate Failure)
    float state_of_health_pct{100.0f}; // Estimated SOH %
    uint32_t total_fault_count{0};
    uint32_t system_uptime_sec{0};
    SeverityLevel severity{SeverityLevel::NOMINAL};
    char operator_recommendation[128]{0};
    char executive_summary[128]{0};
};

class AnalyticsEngine {
public:
    AnalyticsEngine() = default;

    void update(
        const SystemMetrics& bms_metrics,
        SystemState fsm_state,
        FaultSource fault_src,
        uint8_t fault_id,
        bool sensor_anomaly
    ) {
        uint32_t now_sec = millis() / 1000;
        m_metrics.system_uptime_sec = now_sec;

        // 1. Calculate Composite Risk Score (0 - 100)
        float risk_delta_v = std::min(100.0f, (bms_metrics.delta_voltage_mV / bms_metrics.dynamic_threshold_mV) * 100.0f);
        float risk_soc = 0.0f;
        if (bms_metrics.pack_soc_pct < 15.0f || bms_metrics.pack_soc_pct > 85.0f) {
            risk_soc = 50.0f;
        } else if (bms_metrics.pack_soc_pct < 20.0f || bms_metrics.pack_soc_pct > 80.0f) {
            risk_soc = 25.0f;
        }

        float risk_trend = (bms_metrics.trend == ImbalanceTrend::EXPANDING) ? 60.0f : 0.0f;
        float risk_fsm = 0.0f;

        switch (fsm_state) {
            case SystemState::NORMAL:   risk_fsm = 0.0f;   break;
            case SystemState::DEGRADED: risk_fsm = 35.0f;  break;
            case SystemState::FAILSAFE: risk_fsm = 85.0f;  break;
            case SystemState::SHUTDOWN: risk_fsm = 100.0f; break;
        }

        // Weighted sum calculation
        m_metrics.composite_risk_score = (0.35f * risk_delta_v) + 
                                         (0.25f * risk_fsm) + 
                                         (0.20f * risk_soc) + 
                                         (0.20f * risk_trend);

        // Clamp to [0, 100]
        m_metrics.composite_risk_score = std::min(100.0f, std::max(0.0f, m_metrics.composite_risk_score));

        // Track total faults trapped
        if (fsm_state == SystemState::FAILSAFE || fsm_state == SystemState::SHUTDOWN) {
            if (!m_was_in_fault) {
                m_metrics.total_fault_count++;
                m_was_in_fault = true;
            }
        } else {
            m_was_in_fault = false;
        }

        // Degradation model for State of Health (SOH)
        m_metrics.state_of_health_pct = std::max(50.0f, 100.0f - (m_metrics.total_fault_count * 1.5f));

        // 2. Classify Severity Level & Colors
        if (fsm_state == SystemState::SHUTDOWN || fsm_state == SystemState::FAILSAFE) {
            m_metrics.severity = SeverityLevel::CRITICAL;
        } else if (fsm_state == SystemState::DEGRADED || m_metrics.composite_risk_score > 40.0f) {
            m_metrics.severity = SeverityLevel::WARNING;
        } else if (m_metrics.composite_risk_score > 20.0f) {
            m_metrics.severity = SeverityLevel::ADVISORY;
        } else {
            m_metrics.severity = SeverityLevel::NOMINAL;
        }

        // 3. Generate Intelligent Operator Recommendations
        generateOperatorRecommendation(bms_metrics, fsm_state, fault_src, fault_id, sensor_anomaly);

        // 4. Generate Executive Summary String
        snprintf(m_metrics.executive_summary, sizeof(m_metrics.executive_summary),
                 "Health:%.0f%% | Risk:%.0f/100 | Faults:%u | Uptime:%us",
                 m_metrics.state_of_health_pct, m_metrics.composite_risk_score,
                 m_metrics.total_fault_count, m_metrics.system_uptime_sec);
    }

    [[nodiscard]] const AnalyticsMetrics& getMetrics() const { return m_metrics; }

    static const char* severityToString(SeverityLevel lvl) {
        switch (lvl) {
            case SeverityLevel::NOMINAL:  return "NOMINAL (GREEN)";
            case SeverityLevel::ADVISORY: return "ADVISORY (YELLOW)";
            case SeverityLevel::WARNING:  return "WARNING (ORANGE)";
            case SeverityLevel::CRITICAL: return "CRITICAL (RED)";
        }
        return "UNKNOWN";
    }

private:
    AnalyticsMetrics m_metrics{};
    bool m_was_in_fault{false};

    void generateOperatorRecommendation(
        const SystemMetrics& bms_metrics,
        SystemState fsm_state,
        FaultSource fault_src,
        uint8_t fault_id,
        bool sensor_anomaly
    ) {
        if (fsm_state == SystemState::SHUTDOWN) {
            snprintf(m_metrics.operator_recommendation, sizeof(m_metrics.operator_recommendation),
                     "CRITICAL: System latched in SHUTDOWN due to Fault #%u (%s). Perform manual hardware reset.",
                     fault_id, FaultStateMachine::sourceToString(fault_src));
        } else if (fsm_state == SystemState::FAILSAFE) {
            snprintf(m_metrics.operator_recommendation, sizeof(m_metrics.operator_recommendation),
                     "ACTION REQUIRED: Pack isolated. Inspect %s harness and allow 3s verification window.",
                     FaultStateMachine::sourceToString(fault_src));
        } else if (sensor_anomaly) {
            snprintf(m_metrics.operator_recommendation, sizeof(m_metrics.operator_recommendation),
                     "MAINTENANCE: Sensor anomaly trapped on cell array. Check ADC sense wire connectivity.");
        } else if (bms_metrics.trend == ImbalanceTrend::EXPANDING) {
            snprintf(m_metrics.operator_recommendation, sizeof(m_metrics.operator_recommendation),
                     "ADVISORY: Cell divergence expanding (Delta V = %.0f mV). Schedule active balancing cycle.",
                     bms_metrics.delta_voltage_mV);
        } else {
            snprintf(m_metrics.operator_recommendation, sizeof(m_metrics.operator_recommendation),
                     "SYSTEM NOMINAL: All cells operating within normal parameter envelope. No action required.");
        }
    }
};

} // namespace BMS

#endif // ANALYTICS_ENGINE_HPP