#ifndef BMS_ENGINE_HPP
#define BMS_ENGINE_HPP

#include <array>
#include <cstdint>
#include <algorithm>
#include <numeric>
#include <cmath>

#ifndef CONFIG_BMS_CELL_COUNT
#define CONFIG_BMS_CELL_COUNT 4
#endif

namespace BMS {

enum class ImbalanceTrend {
    STABLE = 0,
    EXPANDING,  // Imbalance is increasing over time
    SHRINKING   // Imbalance is decreasing over time
};

struct CellMetrics {
    float voltage_mV{0.0f};
};

struct SystemMetrics {
    uint8_t min_cell_index{0};
    uint8_t max_cell_index{0};
    float min_voltage_mV{0.0f};
    float max_voltage_mV{0.0f};
    float delta_voltage_mV{0.0f};      // Max - Min
    float avg_voltage_mV{0.0f};
    float pack_current_A{0.0f};        // Positive = Discharge, Negative = Charge
    float pack_soc_pct{0.0f};          // State of Charge (0.0% to 100.0%)
    float dynamic_threshold_mV{0.0f};  // Calculated adaptive threshold limit
    bool threshold_exceeded{false};     // Flag if imbalance violates adaptive limit
    ImbalanceTrend trend{ImbalanceTrend::STABLE};
};

template <size_t NCELLS = CONFIG_BMS_CELL_COUNT>
class Engine {
    static_assert(NCELLS > 0 && NCELLS <= 32, "BMS Engine supports 1 to 32 cells.");

public:
    Engine() = default;

    // Primary data ingestion interface with voltage, current, and SoC
    void updateData(const std::array<float, NCELLS>& raw_voltages_mV, float pack_current_A, float pack_soc_pct) {
        m_current_A = pack_current_A;
        m_soc_pct = pack_soc_pct;

        for (size_t i = 0; i < NCELLS; ++i) {
            m_cells[i].voltage_mV = raw_voltages_mV[i];
        }

        processMetrics();
    }

    // Read-only getter interfaces for task reuse
    [[nodiscard]] const SystemMetrics& getMetrics() const { return m_metrics; }
    [[nodiscard]] const std::array<CellMetrics, NCELLS>& getCells() const { return m_cells; }

private:
    std::array<CellMetrics, NCELLS> m_cells{};
    SystemMetrics m_metrics{};
    float m_current_A{0.0f};
    float m_soc_pct{100.0f};

    // Exponential Moving Average (EMA) state for derivative tracking
    float m_prev_delta_mV{0.0f};
    float m_delta_rate_of_change{0.0f};
    static constexpr float EMA_ALPHA = 0.25f; // Filter weight for derivative noise rejection

    void processMetrics() {
        // 1. Min, Max, and Average calculation in single O(N) pass
        auto [min_it, max_it] = std::minmax_element(
            m_cells.begin(), m_cells.end(),
            [](const CellMetrics& a, const CellMetrics& b) {
                return a.voltage_mV < b.voltage_mV;
            }
        );

        m_metrics.min_cell_index = static_cast<uint8_t>(std::distance(m_cells.begin(), min_it));
        m_metrics.max_cell_index = static_cast<uint8_t>(std::distance(m_cells.begin(), max_it));
        m_metrics.min_voltage_mV = min_it->voltage_mV;
        m_metrics.max_voltage_mV = max_it->voltage_mV;
        m_metrics.delta_voltage_mV = m_metrics.max_voltage_mV - m_metrics.min_voltage_mV;

        float total_voltage = std::accumulate(
            m_cells.begin(), m_cells.end(), 0.0f,
            [](float sum, const CellMetrics& cell) {
                return sum + cell.voltage_mV;
            }
        );
        m_metrics.avg_voltage_mV = total_voltage / NCELLS;
        m_metrics.pack_current_A = m_current_A;
        m_metrics.pack_soc_pct = m_soc_pct;

        // 2. Trend Analysis (Filtered Derivative of Delta Voltage)
        float raw_change = m_metrics.delta_voltage_mV - m_prev_delta_mV;
        m_delta_rate_of_change = (EMA_ALPHA * raw_change) + ((1.0f - EMA_ALPHA) * m_delta_rate_of_change);
        m_prev_delta_mV = m_metrics.delta_voltage_mV;

        // Classify trend direction
        if (m_delta_rate_of_change > 0.3f) {
            m_metrics.trend = ImbalanceTrend::EXPANDING;
        } else if (m_delta_rate_of_change < -0.3f) {
            m_metrics.trend = ImbalanceTrend::SHRINKING;
        } else {
            m_metrics.trend = ImbalanceTrend::STABLE;
        }

        // 3. Adaptive Threshold Computation
        m_metrics.dynamic_threshold_mV = calculateAdaptiveThreshold(m_soc_pct, m_current_A);
        m_metrics.threshold_exceeded = (m_metrics.delta_voltage_mV > m_metrics.dynamic_threshold_mV);
    }

    // Adaptive threshold function modeling Lithium-ion non-linear curves
    float calculateAdaptiveThreshold(float soc, float current) const {
        float base_threshold = 20.0f; // Nominal allowed delta = 20 mV (in 20%-80% SoC zone)

        // Non-linear SoC Compensation: Relax threshold near full or empty battery state
        if (soc < 10.0f || soc > 90.0f) {
            base_threshold += 25.0f; // +25 mV allowance at extreme ends of OCV curve
        } else if (soc < 20.0f || soc > 80.0f) {
            base_threshold += 10.0f; // +10 mV allowance at moderate knee regions
        }

        // Current (IR-drop) Compensation: High discharge/charge current causes artificial delta
        // Allowance rate: +5 mV per 10 Amps of pack current
        float current_compensation = (std::abs(current) / 10.0f) * 5.0f;

        return base_threshold + current_compensation;
    }
};

} // namespace BMS

#endif // BMS_ENGINE_HPP