#define BLYNK_TEMPLATE_ID "TMPL3Hyi-DQgK"
#define BLYNK_TEMPLATE_NAME "BMS Enterprise Dashboard"
#define BLYNK_AUTH_TOKEN "3g--ysFRP9B44eZMWFry_UqCQaOtkP30"

#define BLYNK_PRINT Serial
#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

#include "BmsEngine.hpp"
#include "ProtectionRelay.hpp"
#include "SensorDiagnostics.hpp"
#include "LcdEngine.hpp"
#include "DisplayManager.hpp"
#include "FaultStateMachine.hpp"
#include "RelayMonitor.hpp"
#include "TelemetryManager.hpp"
#include "AnalyticsEngine.hpp"

// Wi-Fi Credentials
char ssid[] = "Thanks";
char pass[] = "12345678";

// System Component Instances
BMS::Engine<4> bmsEngine;
BMS::ProtectionRelay protectionRelay;
BMS::SensorDiagnostics<4> sensorDiag;
BMS::LcdEngine<2, 16> lcdEngine;
BMS::DisplayManager displayManager(3000);
BMS::FaultStateMachine fsm;
BMS::TelemetryManager telemetry(ssid, pass);
BMS::AnalyticsEngine analyticsEngine;

SemaphoreHandle_t systemMutex;

struct SharedData {
  std::array<float, 4> voltages_mV{3300.0f, 3305.0f, 3295.0f, 3302.0f};
  float current_A{5.0f};
  float soc_pct{65.0f};
  bool relay_sense_closed{true};
};

SharedData globalData;

// ============================================================================
// FreeRTOS Task: Safety, Analytics & Telemetry Task (20 Hz)
// ============================================================================
void vSafetyTask(void *pvParameters) {
  TickType_t xLastWakeTime = xTaskGetTickCount();
  const TickType_t xFrequency = pdMS_TO_TICKS(50); // 20 Hz

  BMS::SystemState prev_state = BMS::SystemState::NORMAL;

  for (;;) {
    // 1. Maintain Blynk Cloud connection
    if (Blynk.connected()) {
      Blynk.run();
    } else {
      Blynk.connect(); // Re-establish if disconnected
    }

    SharedData copy;
    if (xSemaphoreTake(systemMutex, portMAX_DELAY) == pdTRUE) {
      copy = globalData;
      xSemaphoreGive(systemMutex);
    }

    // 2. Run Diagnostics
    bool anomaly = sensorDiag.processDiagnostics(copy.voltages_mV);

    // 3. Process Core BMS Engine
    bmsEngine.updateData(copy.voltages_mV, copy.current_A, copy.soc_pct);
    const auto& metrics = bmsEngine.getMetrics();

    // 4. Relay Mismatch Check
    bool relay_mismatch = BMS::RelayMonitor::checkMismatch(protectionRelay.isRelayClosed(), copy.relay_sense_closed);

    // 5. Update Fault State Machine
    fsm.update(
      metrics.threshold_exceeded,
      (metrics.delta_voltage_mV > 15.0f && !metrics.threshold_exceeded),
      relay_mismatch,
      anomaly
    );

    // 6. Update Protection Relay
    bool trip = (fsm.getState() == BMS::SystemState::FAILSAFE) || (fsm.getState() == BMS::SystemState::SHUTDOWN);
    protectionRelay.update(metrics.max_voltage_mV, trip);

    // 7. Update Task 6 Analytics Engine
    analyticsEngine.update(
      metrics,
      fsm.getState(),
      fsm.getActiveFaultSource(),
      fsm.getActiveFaultId(),
      anomaly
    );
    const auto& analytics = analyticsEngine.getMetrics();

    bool state_changed = (fsm.getState() != prev_state);
    prev_state = fsm.getState();

    // 8. DIRECT BLYNK VIRTUAL PIN WRITES (Rate-Limited to 1 Hz)
    static uint32_t last_blynk_send = 0;
    uint32_t now = millis();

    if (Blynk.connected() && (now - last_blynk_send >= 1000 || state_changed)) {
      last_blynk_send = now;

      Blynk.virtualWrite(V0, static_cast<int>(fsm.getState()));
      Blynk.virtualWrite(V1, static_cast<int>(protectionRelay.getState()));
      Blynk.virtualWrite(V2, metrics.delta_voltage_mV);
      Blynk.virtualWrite(V3, metrics.pack_current_A);
      Blynk.virtualWrite(V4, metrics.pack_soc_pct);
      Blynk.virtualWrite(V5, WiFi.RSSI());
      Blynk.virtualWrite(V6, 0); // Queue depth
      Blynk.virtualWrite(V7, analytics.composite_risk_score);
      Blynk.virtualWrite(V8, analytics.state_of_health_pct);
      Blynk.virtualWrite(V9, BMS::AnalyticsEngine::severityToString(analytics.severity));
      Blynk.virtualWrite(V10, analytics.operator_recommendation);
      Blynk.virtualWrite(V11, analytics.executive_summary);
    }

    // 9. Process Local Telemetry Logging & Offline Queue
    BMS::TelemetryPayload payload;
    payload.timestamp_ms = now;
    payload.system_state = static_cast<uint8_t>(fsm.getState());
    payload.relay_state = static_cast<uint8_t>(protectionRelay.getState());
    payload.min_cell_idx = metrics.min_cell_index;
    payload.max_cell_idx = metrics.max_cell_index;
    payload.min_voltage_mV = metrics.min_voltage_mV;
    payload.max_voltage_mV = metrics.max_voltage_mV;
    payload.delta_voltage_mV = metrics.delta_voltage_mV;
    payload.pack_current_A = metrics.pack_current_A;
    payload.pack_soc_pct = metrics.pack_soc_pct;
    payload.composite_risk_score = analytics.composite_risk_score;
    payload.state_of_health_pct = analytics.state_of_health_pct;

    telemetry.updateNetwork();
    telemetry.processTelemetry(payload, state_changed);

    vTaskDelayUntil(&xLastWakeTime, xFrequency);
  }
}

// ============================================================================
// FreeRTOS Task: Scenario Fault Injector & Analytics Console Logger (1 Hz)
// ============================================================================
void vInjectorTask(void *pvParameters) {
  uint32_t step = 0;

  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(4000)); // Shift scenario every 4 seconds
    step = (step + 1) % 4;

    if (xSemaphoreTake(systemMutex, portMAX_DELAY) == pdTRUE) {
      switch (step) {
        case 0: // Nominal Operation
          globalData.voltages_mV = {3300.0f, 3305.0f, 3295.0f, 3302.0f};
          globalData.current_A = 2.0f;
          globalData.soc_pct = 75.0f;
          globalData.relay_sense_closed = true;
          break;

        case 1: // Cell Voltage Divergence (Warning)
          globalData.voltages_mV = {3300.0f, 3328.0f, 3290.0f, 3302.0f};
          globalData.current_A = 15.0f;
          globalData.soc_pct = 50.0f;
          break;

        case 2: // Injected Critical Overvoltage Fault
          globalData.voltages_mV = {4230.0f, 3305.0f, 3295.0f, 3302.0f};
          break;

        case 3: // Recover to Normal
          globalData.voltages_mV = {3300.0f, 3305.0f, 3295.0f, 3302.0f};
          globalData.current_A = 2.0f;
          globalData.soc_pct = 75.0f;
          globalData.relay_sense_closed = true;
          break;
      }

      const auto& analytics = analyticsEngine.getMetrics();
      Serial.println("\n=== TASK 6: ENTERPRISE BLYNK ANALYTICS DASHBOARD ===");
      Serial.print("  Executive Summary  : "); Serial.println(analytics.executive_summary);
      Serial.print("  Composite Risk     : "); Serial.print(analytics.composite_risk_score); Serial.println("/100");
      Serial.print("  State of Health    : "); Serial.print(analytics.state_of_health_pct); Serial.println("%");
      Serial.print("  Severity Level     : "); Serial.println(BMS::AnalyticsEngine::severityToString(analytics.severity));
      Serial.print("  Operator Action    : "); Serial.println(analytics.operator_recommendation);
      Serial.println("=====================================================");

      xSemaphoreGive(systemMutex);
    }
  }
}

void setup() {
  Serial.begin(115200);
  delay(2000);

  Serial.println("\n===========================================================");
  Serial.println("  Task 6: Master BMS Firmware (Tasks 1-6 Fully Integrated) ");
  Serial.println("===========================================================");

  // Initialize Blynk Cloud Connection
  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  systemMutex = xSemaphoreCreateMutex();

  if (systemMutex != NULL) {
    // Increased vSafetyTask stack size from 4096 to 8192 bytes for stability
    xTaskCreatePinnedToCore(vSafetyTask, "SafetyTask", 8192, NULL, 3, NULL, 1);
    xTaskCreatePinnedToCore(vInjectorTask, "InjectorTask", 4096, NULL, 2, NULL, 1);
  }
}

void loop() {
  // Empty — all multi-threading handled by FreeRTOS tasks
}