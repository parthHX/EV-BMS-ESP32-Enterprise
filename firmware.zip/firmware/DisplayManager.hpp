#ifndef DISPLAY_MANAGER_HPP
#define DISPLAY_MANAGER_HPP

#include "LcdEngine.hpp"
#include "BmsEngine.hpp"
#include "ProtectionRelay.hpp"
#include "SensorDiagnostics.hpp"

namespace BMS {

class DisplayManager {
public:
    explicit DisplayManager(uint32_t page_rotation_ms = 3000)
        : m_rotation_period_ms(page_rotation_ms) {}

    // Main non-blocking update routine
    void update(
        LcdEngine<2, 16>& lcdEngine,
        const SystemMetrics& metrics,
        const ProtectionRelay& relay,
        const SensorDiagnostics<4>& diag
    ) {
        uint32_t now = millis();

        // 1. CRITICAL OVERRIDE CHECK
        bool is_critical_fault = (relay.getState() == RelayState::OPEN_FAULT) || diag.hasFault();

        if (is_critical_fault) {
            m_active_page = DisplayPage::FAULT_OVERRIDE;
        } else {
            // Auto page rotation timer when system is healthy
            if (m_active_page == DisplayPage::FAULT_OVERRIDE) {
                m_active_page = DisplayPage::BATTERY_STATUS; // Return to Page 1 upon recovery
                m_last_page_swap_ms = now;
            } else if (now - m_last_page_swap_ms >= m_rotation_period_ms) {
                m_last_page_swap_ms = now;
                rotateToNextPage();
            }
        }

        // 2. Render content to virtual buffer
        renderPage(lcdEngine, metrics, relay, diag);
    }

    [[nodiscard]] DisplayPage getActivePage() const { return m_active_page; }

private:
    DisplayPage m_active_page{DisplayPage::BATTERY_STATUS};
    uint32_t m_last_page_swap_ms{0};
    uint32_t m_rotation_period_ms{3000}; // 3-second page rotation

    void rotateToNextPage() {
        switch (m_active_page) {
            case DisplayPage::BATTERY_STATUS: m_active_page = DisplayPage::SYSTEM_STATE; break;
            case DisplayPage::SYSTEM_STATE:   m_active_page = DisplayPage::TELEMETRY_DIAG; break;
            case DisplayPage::TELEMETRY_DIAG: m_active_page = DisplayPage::BATTERY_STATUS; break;
            default:                          m_active_page = DisplayPage::BATTERY_STATUS; break;
        }
    }

    void renderPage(
        LcdEngine<2, 16>& lcd,
        const SystemMetrics& metrics,
        const ProtectionRelay& relay,
        const SensorDiagnostics<4>& diag
    ) {
        switch (m_active_page) {
            case DisplayPage::BATTERY_STATUS:
                // Page 1: Battery Voltages & Delta
                lcd.printfLine(0, "P1:Min%d Max%d", metrics.min_cell_index, metrics.max_cell_index);
                lcd.printfLine(1, "dV:%d Dynamic:%d", (int)metrics.delta_voltage_mV, (int)metrics.dynamic_threshold_mV);
                break;

            case DisplayPage::SYSTEM_STATE:
                // Page 2: System Operating State, Current, SoC (Updated member names here)
                lcd.printfLine(0, "P2:SoC:%d%% I:%dA", (int)metrics.pack_soc_pct, (int)metrics.pack_current_A);
                lcd.printfLine(1, "Relay:%s", relay.getStateString());
                break;

            case DisplayPage::TELEMETRY_DIAG:
                // Page 3: Sensor Diagnostic Summary
                lcd.printfLine(0, "P3:Diag Status");
                lcd.printfLine(1, "%s", diag.hasFault() ? "ANOMALY DETECTED" : "SENSORS HEALTHY");
                break;

            case DisplayPage::FAULT_OVERRIDE:
                // CRITICAL FAULT OVERRIDE DISPLAY
                lcd.printfLine(0, "!CRITICAL FAULT!");
                if (diag.hasFault()) {
                    lcd.printfLine(1, "SENSOR ANOMALY");
                } else {
                    lcd.printfLine(1, "OVERVOLT RELAY");
                }
                break;
        }
    }
};

} // namespace BMS

#endif // DISPLAY_MANAGER_HPP