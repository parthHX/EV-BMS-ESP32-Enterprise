#ifndef FAULT_STATE_MACHINE_HPP
#define FAULT_STATE_MACHINE_HPP

#include <Arduino.h>
#include <cstdint>

namespace BMS {

// Four Primary Operating States
enum class SystemState {
    NORMAL = 0,   // Full functionality
    DEGRADED,     // Operating with non-critical warnings
    FAILSAFE,     // Relay open, isolating pack, verifying fault clearance
    SHUTDOWN      // Latched safety power-down
};

// Fault Source Classification
enum class FaultSource {
    NONE = 0,
    BATTERY_CELL, // Cell overvoltage / severe imbalance
    RELAY,        // Relay contacts welded / coil mismatch
    COMMUNICATION,// Bus / telemetry loss
    ADC_HARDWARE  // Frozen ADC / rail short
};

struct FaultLogEntry {
    uint32_t timestamp_ms{0};
    SystemState prev_state{SystemState::NORMAL};
    SystemState new_state{SystemState::NORMAL};
    FaultSource source{FaultSource::NONE};
    uint8_t fault_id{0};
    char description[64]{0};
};

class FaultStateMachine {
public:
    FaultStateMachine() = default;

    // Process system health inputs and execute deterministic transitions
    void update(
        bool critical_cell_fault,
        bool minor_warning,
        bool relay_mismatch_fault,
        bool adc_frozen_fault
    ) {
        uint32_t now = millis();

        // 1. Evaluate highest-priority fault source
        FaultSource current_source = FaultSource::NONE;
        uint8_t current_fault_id = 0;

        if (relay_mismatch_fault) {
            current_source = FaultSource::RELAY;
            current_fault_id = 101; // Relay coil vs feedback mismatch
        } else if (adc_frozen_fault) {
            current_source = FaultSource::ADC_HARDWARE;
            current_fault_id = 202; // Frozen ADC hardware channel
        } else if (critical_cell_fault) {
            current_source = FaultSource::BATTERY_CELL;
            current_fault_id = 303; // Overvoltage or severe cell delta
        } else if (minor_warning) {
            current_source = FaultSource::BATTERY_CELL;
            current_fault_id = 301; // Minor imbalance warning
        }

        // 2. Deterministic State Machine Transitions
        switch (m_current_state) {
            case SystemState::NORMAL:
                if (current_source == FaultSource::RELAY || current_source == FaultSource::ADC_HARDWARE || critical_cell_fault) {
                    transitionTo(SystemState::FAILSAFE, current_source, current_fault_id, "Critical fault detected");
                } else if (minor_warning) {
                    transitionTo(SystemState::DEGRADED, current_source, current_fault_id, "Minor cell warning");
                }
                break;

            case SystemState::DEGRADED:
                if (current_source == FaultSource::RELAY || current_source == FaultSource::ADC_HARDWARE || critical_cell_fault) {
                    transitionTo(SystemState::FAILSAFE, current_source, current_fault_id, "Degraded escalated to Critical");
                } else if (!minor_warning && current_source == FaultSource::NONE) {
                    // Verification timer to return from DEGRADED to NORMAL
                    if (m_verification_start_ms == 0) {
                        m_verification_start_ms = now;
                    } else if (now - m_verification_start_ms >= NORMAL_RECOVERY_WINDOW_MS) {
                        transitionTo(SystemState::NORMAL, FaultSource::NONE, 0, "System fully healthy");
                        m_verification_start_ms = 0;
                    }
                } else {
                    m_verification_start_ms = 0; // Reset timer if warning persists
                }
                break;

            case SystemState::FAILSAFE:
                // Check if all faults are cleared during FAILSAFE
                if (current_source == FaultSource::NONE) {
                    if (m_verification_start_ms == 0) {
                        m_verification_start_ms = now;
                    } else if (now - m_verification_start_ms >= FAILSAFE_VERIFICATION_WINDOW_MS) {
                        // Staged recovery: Transition to DEGRADED first (not immediate NORMAL)
                        transitionTo(SystemState::DEGRADED, FaultSource::NONE, 0, "Verification passed: FAILSAFE -> DEGRADED");
                        m_verification_start_ms = 0;
                    }
                } else {
                    m_verification_start_ms = 0; // Reset verification timer on active fault

                    // Track consecutive failed recovery attempts
                    m_failed_recovery_count++;
                    if (m_failed_recovery_count >= MAX_FAILED_RECOVERIES) {
                        transitionTo(SystemState::SHUTDOWN, current_source, current_fault_id, "Max recovery retries exceeded");
                    }
                }
                break;

            case SystemState::SHUTDOWN:
                // Latched state — system remains isolated until hardware reset
                break;
        }
    }

    [[nodiscard]] SystemState getState() const { return m_current_state; }
    [[nodiscard]] FaultSource getActiveFaultSource() const { return m_active_source; }
    [[nodiscard]] uint8_t getActiveFaultId() const { return m_active_fault_id; }

    static const char* stateToString(SystemState state) {
        switch (state) {
            case SystemState::NORMAL:   return "NORMAL";
            case SystemState::DEGRADED: return "DEGRADED";
            case SystemState::FAILSAFE: return "FAILSAFE";
            case SystemState::SHUTDOWN: return "SHUTDOWN";
        }
        return "UNKNOWN";
    }

    static const char* sourceToString(FaultSource source) {
        switch (source) {
            case FaultSource::NONE:         return "NONE";
            case FaultSource::BATTERY_CELL: return "BATTERY_CELL";
            case FaultSource::RELAY:        return "RELAY";
            case FaultSource::COMMUNICATION:return "COMMUNICATION";
            case FaultSource::ADC_HARDWARE: return "ADC_HARDWARE";
        }
        return "UNKNOWN";
    }

private:
    SystemState m_current_state{SystemState::NORMAL};
    FaultSource m_active_source{FaultSource::NONE};
    uint8_t m_active_fault_id{0};

    uint32_t m_verification_start_ms{0};
    uint8_t m_failed_recovery_count{0};

    static constexpr uint32_t FAILSAFE_VERIFICATION_WINDOW_MS = 3000; // Must remain clear for 3s
    static constexpr uint32_t NORMAL_RECOVERY_WINDOW_MS   = 2000; // Must remain clear for 2s
    static constexpr uint8_t  MAX_FAILED_RECOVERIES        = 50;   // Retries before hard SHUTDOWN

    void transitionTo(SystemState new_state, FaultSource source, uint8_t fault_id, const char* desc) {
        FaultLogEntry log;
        log.timestamp_ms = millis();
        log.prev_state = m_current_state;
        log.new_state = new_state;
        log.source = source;
        log.fault_id = fault_id;
        snprintf(log.description, sizeof(log.description), "%s", desc);

        m_current_state = new_state;
        m_active_source = source;
        m_active_fault_id = fault_id;

        // Structured Event Logging Output
        Serial.println("\n-----------------------------------------------------------");
        Serial.print("[STATE TRANSITION @ "); Serial.print(log.timestamp_ms); Serial.println(" ms]");
        Serial.print("  Previous State : "); Serial.println(stateToString(log.prev_state));
        Serial.print("  New State      : "); Serial.println(stateToString(log.new_state));
        Serial.print("  Fault Source   : "); Serial.println(sourceToString(log.source));
        Serial.print("  Fault ID       : "); Serial.println(log.fault_id);
        Serial.print("  Reason         : "); Serial.println(log.description);
        Serial.println("-----------------------------------------------------------");
    }
};

} // namespace BMS

#endif // FAULT_STATE_MACHINE_HPP