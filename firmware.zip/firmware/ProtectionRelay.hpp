#ifndef PROTECTION_RELAY_HPP
#define PROTECTION_RELAY_HPP

#include <Arduino.h>
#include <cstdint>

namespace BMS {

enum class RelayState {
    CLOSED_NORMAL,      // Relay closed, power connected
    DEBOUNCING_TRIP,    // Fault detected, counting debounce duration
    OPEN_FAULT,         // Relay tripped OPEN due to active fault
    DEBOUNCING_RECOVERY // Fault cleared, waiting out recovery delay before reconnecting
};

struct RelayConfig {
    float overvoltage_trip_mV{4200.0f};      // Trip threshold
    float overvoltage_release_mV{4150.0f};   // Hysteresis recovery threshold
    uint32_t trip_debounce_ms{200};          // Must stay faulted for 200ms before trip
    uint32_t recovery_delay_ms{2000};        // Must stay clean for 2000ms before close
};

class ProtectionRelay {
public:
    explicit ProtectionRelay(const RelayConfig& config = RelayConfig{})
        : m_config(config) {}

    // Non-blocking update function driven by millis()
    void update(float max_cell_voltage_mV, bool engine_fault_active) {
        uint32_t now = millis();

        // Check if raw overvoltage condition exists with hysteresis
        bool raw_overvoltage = false;
        if (m_state == RelayState::CLOSED_NORMAL || m_state == RelayState::DEBOUNCING_TRIP) {
            raw_overvoltage = (max_cell_voltage_mV >= m_config.overvoltage_trip_mV);
        } else { // In FAULT or RECOVERY state, use lower release threshold (Hysteresis)
            raw_overvoltage = (max_cell_voltage_mV >= m_config.overvoltage_release_mV);
        }

        bool active_fault = raw_overvoltage || engine_fault_active;

        // Non-blocking State Machine
        switch (m_state) {
            case RelayState::CLOSED_NORMAL:
                if (active_fault) {
                    m_state = RelayState::DEBOUNCING_TRIP;
                    m_state_timer = now;
                    logTransition("NORMAL -> DEBOUNCING_TRIP", "Fault detected, starting trip timer");
                }
                break;

            case RelayState::DEBOUNCING_TRIP:
                if (!active_fault) {
                    m_state = RelayState::CLOSED_NORMAL;
                    logTransition("DEBOUNCING_TRIP -> NORMAL", "Transient fault cleared within debounce window");
                } else if (now - m_state_timer >= m_config.trip_debounce_ms) {
                    m_state = RelayState::OPEN_FAULT;
                    logTransition("DEBOUNCING_TRIP -> OPEN_FAULT", "TRIPPED RELAY: Debounce duration exceeded!");
                }
                break;

            case RelayState::OPEN_FAULT:
                if (!active_fault) {
                    m_state = RelayState::DEBOUNCING_RECOVERY;
                    m_state_timer = now;
                    logTransition("OPEN_FAULT -> DEBOUNCING_RECOVERY", "Fault cleared, starting recovery timer");
                }
                break;

            case RelayState::DEBOUNCING_RECOVERY:
                if (active_fault) {
                    m_state = RelayState::OPEN_FAULT;
                    logTransition("DEBOUNCING_RECOVERY -> OPEN_FAULT", "Fault re-occurred during recovery window");
                } else if (now - m_state_timer >= m_config.recovery_delay_ms) {
                    m_state = RelayState::CLOSED_NORMAL;
                    logTransition("DEBOUNCING_RECOVERY -> CLOSED_NORMAL", "RECONNECTED RELAY: Timed recovery complete");
                }
                break;
        }
    }

    [[nodiscard]] RelayState getState() const { return m_state; }
    [[nodiscard]] bool isRelayClosed() const { return m_state == RelayState::CLOSED_NORMAL; }

    const char* getStateString() const {
        switch (m_state) {
            case RelayState::CLOSED_NORMAL:      return "CLOSED_NORMAL";
            case RelayState::DEBOUNCING_TRIP:    return "DEBOUNCING_TRIP";
            case RelayState::OPEN_FAULT:         return "OPEN_FAULT";
            case RelayState::DEBOUNCING_RECOVERY:return "DEBOUNCING_RECOVERY";
        }
        return "UNKNOWN";
    }

private:
    RelayConfig m_config;
    RelayState m_state{RelayState::CLOSED_NORMAL};
    uint32_t m_state_timer{0};

    void logTransition(const char* transition, const char* reason) const {
        Serial.print("[RELAY EVENT ");
        Serial.print(millis());
        Serial.print(" ms] ");
        Serial.print(transition);
        Serial.print(" | Reason: ");
        Serial.println(reason);
    }
};

} // namespace BMS

#endif // PROTECTION_RELAY_HPP