#ifndef RELAY_MONITOR_HPP
#define RELAY_MONITOR_HPP

#include <Arduino.h>

namespace BMS {

class RelayMonitor {
public:
    // Non-blocking check to ensure relay driver output matches physical sense pin
    static bool checkMismatch(bool command_close, bool physical_sense_closed) {
        // Mismatch exists if command is CLOSE but sense pin reads OPEN (or vice versa)
        return (command_close != physical_sense_closed);
    }
};

} // namespace BMS

#endif // RELAY_MONITOR_HPP