#ifndef SENSOR_DIAGNOSTICS_HPP
#define SENSOR_DIAGNOSTICS_HPP

#include <array>
#include <cmath>
#include <cstdint>

namespace BMS {

enum class DiagnosticFault {
    NONE = 0,
    OUT_OF_RANGE_LOW,    // Sensor output < 2000 mV (Disconnected wire / short)
    OUT_OF_RANGE_HIGH,   // Sensor output > 4500 mV (ADC rail short)
    UNREALISTIC_JUMP,    // Delta change > 300 mV in a single frame
    FROZEN_READING       // Reading flatlined for 50+ consecutive samples
};

struct DiagnosticConfig {
    float min_valid_voltage_mV{2000.0f};  // Physical lower boundary
    float max_valid_voltage_mV{4500.0f};  // Physical upper boundary
    float max_allowed_jump_mV{300.0f};    // Max rate of change threshold
    uint16_t frozen_sample_limit{50};     // Number of static samples before frozen alert
};

template <size_t NCELLS = 4>
class SensorDiagnostics {
public:
    explicit SensorDiagnostics(const DiagnosticConfig& config = DiagnosticConfig{})
        : m_config(config) {
        m_prev_voltages.fill(0.0f);
        m_frozen_counters.fill(0);
    }

    // Process a frame of cell voltages and return true if ANY sensor anomaly is detected
    bool processDiagnostics(const std::array<float, NCELLS>& raw_voltages_mV) {
        m_system_has_fault = false;

        for (size_t i = 0; i < NCELLS; ++i) {
            float current_v = raw_voltages_mV[i];
            m_cell_faults[i] = DiagnosticFault::NONE;

            // 1. Absolute Range Check
            if (current_v < m_config.min_valid_voltage_mV) {
                m_cell_faults[i] = DiagnosticFault::OUT_OF_RANGE_LOW;
            } else if (current_v > m_config.max_valid_voltage_mV) {
                m_cell_faults[i] = DiagnosticFault::OUT_OF_RANGE_HIGH;
            }

            // 2. Unrealistic Delta Jump Check (evaluated if previous reading was initialized)
            if (m_cell_faults[i] == DiagnosticFault::NONE && m_prev_voltages[i] > 0.0f) {
                float delta = std::abs(current_v - m_prev_voltages[i]);
                if (delta > m_config.max_allowed_jump_mV) {
                    m_cell_faults[i] = DiagnosticFault::UNREALISTIC_JUMP;
                }
            }

            // 3. Frozen Reading Check
            if (m_cell_faults[i] == DiagnosticFault::NONE && m_prev_voltages[i] > 0.0f) {
                // If voltage is identical to last frame within floating point noise tolerance (0.01 mV)
                if (std::abs(current_v - m_prev_voltages[i]) < 0.01f) {
                    m_frozen_counters[i]++;
                    if (m_frozen_counters[i] >= m_config.frozen_sample_limit) {
                        m_cell_faults[i] = DiagnosticFault::FROZEN_READING;
                    }
                } else {
                    m_frozen_counters[i] = 0; // Reset frozen counter on dynamic signal
                }
            }

            // Store current voltage for next comparison step
            m_prev_voltages[i] = current_v;

            if (m_cell_faults[i] != DiagnosticFault::NONE) {
                m_system_has_fault = true;
            }
        }

        return m_system_has_fault;
    }

    [[nodiscard]] bool hasFault() const { return m_system_has_fault; }
    [[nodiscard]] DiagnosticFault getCellFault(size_t index) const { return m_cell_faults[index]; }

    static const char* faultToString(DiagnosticFault fault) {
        switch (fault) {
            case DiagnosticFault::NONE:              return "HEALTHY";
            case DiagnosticFault::OUT_OF_RANGE_LOW:  return "FAULT: Out of Range (Low / Wire Disconnect)";
            case DiagnosticFault::OUT_OF_RANGE_HIGH: return "FAULT: Out of Range (High / Sensor Short)";
            case DiagnosticFault::UNREALISTIC_JUMP:  return "FAULT: Unrealistic Spike Jump";
            case DiagnosticFault::FROZEN_READING:    return "FAULT: Frozen Sensor Output";
        }
        return "UNKNOWN";
    }

private:
    DiagnosticConfig m_config;
    std::array<float, NCELLS> m_prev_voltages{};
    std::array<uint16_t, NCELLS> m_frozen_counters{};
    std::array<DiagnosticFault, NCELLS> m_cell_faults{};
    bool m_system_has_fault{false};
};

} // namespace BMS

#endif // SENSOR_DIAGNOSTICS_HPP