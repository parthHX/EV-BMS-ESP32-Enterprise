#ifndef SIGNAL_FILTER_HPP
#define SIGNAL_FILTER_HPP

#include <array>
#include <cmath>
#include <numeric>

namespace BMS {

template <size_t WINDOW_SIZE = 8>
class SignalFilter {
public:
    SignalFilter() {
        m_buffer.fill(0.0f);
    }

    // Push new raw sample and compute filtered metrics
    void addSample(float raw_value) {
        m_buffer[m_head] = raw_value;
        m_head = (m_head + 1) % WINDOW_SIZE;

        if (m_count < WINDOW_SIZE) {
            m_count++;
        }

        computeStats();
    }

    [[nodiscard]] float getMean() const { return m_mean; }
    [[nodiscard]] float getStdDev() const { return m_std_dev; }
    
    // Distinguishes true dynamic step change from noisy transient spike
    [[nodiscard]] bool isGenuineLoadStep(float max_expected_noise_std) const {
        // High rate of change with low internal variance = True Load Step
        // Erratic fluctuation around mean = High Noise
        return (m_count >= WINDOW_SIZE) && (m_std_dev < max_expected_noise_std);
    }

private:
    std::array<float, WINDOW_SIZE> m_buffer{};
    size_t m_head{0};
    size_t m_count{0};
    float m_mean{0.0f};
    float m_std_dev{0.0f};

    void computeStats() {
        if (m_count == 0) return;

        float sum = std::accumulate(m_buffer.begin(), m_buffer.begin() + m_count, 0.0f);
        m_mean = sum / m_count;

        float variance_sum = 0.0f;
        for (size_t i = 0; i < m_count; ++i) {
            float diff = m_buffer[i] - m_mean;
            variance_sum += diff * diff;
        }

        m_std_dev = std::sqrt(variance_sum / m_count);
    }
};

} // namespace BMS

#endif // SIGNAL_FILTER_HPP