#ifndef TELEMETRY_MANAGER_HPP
#define TELEMETRY_MANAGER_HPP

#include <Arduino.h>
#include <WiFi.h>
#include <array>
#include <cstdint>
#include <cstring>

// Uncomment when using the official Blynk Library
// #define BLYNK_PRINT Serial
// #include <BlynkSimpleEsp32.h>

namespace BMS {

struct TelemetryPayload {
    uint32_t timestamp_ms{0};
    uint8_t system_state{0};         
    uint8_t relay_state{0};          
    uint8_t min_cell_idx{0};
    uint8_t max_cell_idx{0};
    float min_voltage_mV{0.0f};
    float max_voltage_mV{0.0f};
    float delta_voltage_mV{0.0f};
    float pack_current_A{0.0f};
    float pack_soc_pct{0.0f};
    int8_t rssi_dbm{0};
    bool is_queued_data{false};      
    uint8_t event_id{0};             
    
    // Task 6 Analytics additions
    float composite_risk_score{0.0f};
    float state_of_health_pct{100.0f};
    char severity_str[32]{"NOMINAL"};
    char operator_rec[128]{""};
    char exec_summary[128]{""};
};

template <size_t QUEUE_SIZE = 32>
class OfflineQueue {
public:
    OfflineQueue() = default;

    bool push(const TelemetryPayload& payload) {
        if (isFull()) {
            m_tail = (m_tail + 1) % QUEUE_SIZE;
            m_count--;
        }
        m_buffer[m_head] = payload;
        m_buffer[m_head].is_queued_data = true;
        m_head = (m_head + 1) % QUEUE_SIZE;
        m_count++;
        return true;
    }

    bool pop(TelemetryPayload& payload) {
        if (isEmpty()) return false;
        payload = m_buffer[m_tail];
        m_tail = (m_tail + 1) % QUEUE_SIZE;
        m_count--;
        return true;
    }

    [[nodiscard]] bool isEmpty() const { return m_count == 0; }
    [[nodiscard]] bool isFull() const { return m_count == QUEUE_SIZE; }
    [[nodiscard]] size_t size() const { return m_count; }
    [[nodiscard]] size_t capacity() const { return QUEUE_SIZE; }

private:
    std::array<TelemetryPayload, QUEUE_SIZE> m_buffer{};
    size_t m_head{0};
    size_t m_tail{0};
    size_t m_count{0};
};

enum class WifiState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
};

class TelemetryManager {
public:
    TelemetryManager(const char* ssid, const char* pass)
        : m_ssid(ssid), m_pass(pass) {}

    void updateNetwork() {
        uint32_t now = millis();

        switch (m_wifi_state) {
            case WifiState::DISCONNECTED:
                if (now - m_last_reconnect_attempt_ms >= RECONNECT_INTERVAL_MS) {
                    m_last_reconnect_attempt_ms = now;
                    WiFi.begin(m_ssid, m_pass);
                    m_wifi_state = WifiState::CONNECTING;
                    Serial.println("[WIFI FSM] Initiating non-blocking Wi-Fi connection...");
                }
                break;

            case WifiState::CONNECTING:
                if (WiFi.status() == WL_CONNECTED) {
                    m_wifi_state = WifiState::CONNECTED;
                    Serial.println("[WIFI FSM] Wi-Fi Connected Successfully!");
                } else if (now - m_last_reconnect_attempt_ms >= CONNECTION_TIMEOUT_MS) {
                    m_wifi_state = WifiState::DISCONNECTED;
                    Serial.println("[WIFI FSM] Wi-Fi Connection Timeout. Retrying later...");
                }
                break;

            case WifiState::CONNECTED:
                if (WiFi.status() != WL_CONNECTED) {
                    m_wifi_state = WifiState::DISCONNECTED;
                    Serial.println("[WIFI FSM] Wi-Fi Connection Lost!");
                }
                break;
        }
    }

    void processTelemetry(const TelemetryPayload& current, bool state_changed_event) {
        uint32_t now = millis();
        bool publish_needed = false;

        bool delta_v_changed = std::abs(current.delta_voltage_mV - m_last_sent.delta_voltage_mV) >= DEAD_DELTA_V_MV;
        bool current_changed = std::abs(current.pack_current_A - m_last_sent.pack_current_A) >= DEAD_CURRENT_A;
        bool heartbeat_expired = (now - m_last_publish_ms >= HEARTBEAT_INTERVAL_MS);

        if (state_changed_event || delta_v_changed || current_changed || heartbeat_expired) {
            publish_needed = true;
        }

        if (publish_needed) {
            m_last_publish_ms = now;
            m_last_sent = current;

            TelemetryPayload payload = current;
            payload.rssi_dbm = (m_wifi_state == WifiState::CONNECTED) ? static_cast<int8_t>(WiFi.RSSI()) : 0;

            if (m_wifi_state == WifiState::CONNECTED) {
                // Flush historical buffer first
                flushOfflineQueue();
                
                // Transmit current live event
                transmitToBlynk(payload);
            } else {
                // Network down: Queue offline
                m_offline_queue.push(payload);
                Serial.print("[TELEMETRY QUEUE] Network down. Event buffered. Depth: ");
                Serial.print(m_offline_queue.size());
                Serial.print("/");
                Serial.println(m_offline_queue.capacity());
            }
        }
    }

    [[nodiscard]] WifiState getWifiState() const { return m_wifi_state; }
    [[nodiscard]] size_t getQueueDepth() const { return m_offline_queue.size(); }
    [[nodiscard]] int8_t getRssi() const { return (m_wifi_state == WifiState::CONNECTED) ? static_cast<int8_t>(WiFi.RSSI()) : 0; }

private:
    const char* m_ssid;
    const char* m_pass;
    WifiState m_wifi_state{WifiState::DISCONNECTED};
    OfflineQueue<32> m_offline_queue{};

    TelemetryPayload m_last_sent{};
    uint32_t m_last_publish_ms{0};
    uint32_t m_last_reconnect_attempt_ms{0};

    static constexpr uint32_t RECONNECT_INTERVAL_MS = 10000;
    static constexpr uint32_t CONNECTION_TIMEOUT_MS = 5000;
    static constexpr uint32_t HEARTBEAT_INTERVAL_MS  = 10000;
    static constexpr float    DEAD_DELTA_V_MV        = 10.0f;
    static constexpr float    DEAD_CURRENT_A         = 1.0f;

    void flushOfflineQueue() {
        TelemetryPayload queuedItem;
        while (m_offline_queue.pop(queuedItem)) {
            Serial.print("[QUEUED DATA FLUSH @ ");
            Serial.print(queuedItem.timestamp_ms);
            Serial.println(" ms] Transmitting stored offline event...");
            transmitToBlynk(queuedItem);
        }
    }

    void transmitToBlynk(const TelemetryPayload& payload) {
        // --- REAL BLYNK TRANSMISSION (Uncomment when credentials are configured) ---
        /*
        Blynk.virtualWrite(V0, payload.system_state);
        Blynk.virtualWrite(V1, payload.relay_state);
        Blynk.virtualWrite(V2, payload.delta_voltage_mV);
        Blynk.virtualWrite(V3, payload.pack_current_A);
        Blynk.virtualWrite(V4, payload.pack_soc_pct);
        Blynk.virtualWrite(V5, payload.rssi_dbm);
        Blynk.virtualWrite(V6, m_offline_queue.size());
        
        // Task 6 Enterprise Analytics Virtual Pins
        Blynk.virtualWrite(V7, payload.composite_risk_score);
        Blynk.virtualWrite(V8, payload.state_of_health_pct);
        Blynk.virtualWrite(V9, payload.severity_str);
        Blynk.virtualWrite(V10, payload.operator_rec);
        Blynk.virtualWrite(V11, payload.exec_summary);
        */

        // Console Log Output
        Serial.println("\n>>> [BLYNK TELEMETRY TRANSMIT] >>>");
        Serial.print("  Data Source   : "); Serial.println(payload.is_queued_data ? "HISTORICAL (QUEUED)" : "LIVE REAL-TIME");
        Serial.print("  V0 (SysState) : "); Serial.println(payload.system_state);
        Serial.print("  V1 (Relay)    : "); Serial.println(payload.relay_state);
        Serial.print("  V2 (Delta V)  : "); Serial.print(payload.delta_voltage_mV); Serial.println(" mV");
        Serial.print("  V3 (Current)  : "); Serial.print(payload.pack_current_A); Serial.println(" A");
        Serial.print("  V4 (SoC)      : "); Serial.print(payload.pack_soc_pct); Serial.println(" %");
        Serial.print("  V5 (RSSI)     : "); Serial.print(payload.rssi_dbm); Serial.println(" dBm");
        Serial.print("  V6 (Queue)    : "); Serial.println(m_offline_queue.size());
        Serial.print("  V7 (Risk)     : "); Serial.println(payload.composite_risk_score);
        Serial.print("  V8 (SOH %)    : "); Serial.println(payload.state_of_health_pct);
        Serial.print("  V9 (Severity) : "); Serial.println(payload.severity_str);
        Serial.print("  V10 (Action)  : "); Serial.println(payload.operator_rec);
        Serial.println("==========================================");
    }
};

} // namespace BMS

#endif // TELEMETRY_MANAGER_HPP